const BACKEND_URL = "https://grain-scheming-ellipse.ngrok-free.dev";
const IMAGE_TYPES = new Set(["jpg","jpeg","png","gif","webp","bmp"]);

let state = { attachments: [], selected: null, blurredB64: null, boxes: [], processing: false };

const $list     = document.getElementById("attachment-list");
const $btnScan  = document.getElementById("btn-scan");
const $btnRefresh = document.getElementById("btn-refresh");
const $btnReplace = document.getElementById("btn-replace");
const $btnDiscard = document.getElementById("btn-discard");
const $status   = document.getElementById("status-bar");
const $statusTxt= document.getElementById("status-text");
const $preview  = document.getElementById("preview-section");
const $canvas   = document.getElementById("preview-canvas");
const $boxCount = document.getElementById("box-count");
const ctx       = $canvas.getContext("2d");

Office.onReady(() => {
  loadAttachments();
  $btnRefresh.addEventListener("click", loadAttachments);
  $btnScan.addEventListener("click", onScan);
  $btnReplace.addEventListener("click", onReplace);
  $btnDiscard.addEventListener("click", onDiscard);
});

function loadAttachments() {
  resetPreview();
  $list.innerHTML = "";
  const atts = Office.context.mailbox.item.attachments || [];
  state.attachments = atts.filter(a => {
    const ext = (a.name || "").split(".").pop().toLowerCase();
    return IMAGE_TYPES.has(ext);
  });
  if (state.attachments.length === 0) {
    $list.innerHTML = `<div class="no-attachments">No image attachments found.<br>Attach a PNG or JPEG first.</div>`;
    $btnScan.disabled = true;
    return;
  }
  state.attachments.forEach(att => {
    const div = document.createElement("div");
    div.className = "attachment-item";
    div.dataset.id = att.id;
    div.innerHTML = `<span class="att-icon">🖼️</span><span class="att-name" title="${esc(att.name)}">${esc(att.name)}</span><span class="att-badge" id="badge-${att.id}">unscanned</span>`;
    div.addEventListener("click", () => selectAttachment(att.id));
    $list.appendChild(div);
  });
}

function selectAttachment(id) {
  state.selected = id;
  state.blurredB64 = null;
  state.boxes = [];
  resetPreview();
  document.querySelectorAll(".attachment-item").forEach(el => {
    el.classList.toggle("selected", el.dataset.id === id);
  });
  $btnScan.disabled = false;
}

async function onScan() {
  if (!state.selected || state.processing) return;
  state.processing = true;
  $btnScan.disabled = true;
  setStatus("Reading attachment…", true);
  resetPreview();
  try {
    const b64 = await readAttachmentAsBase64(state.selected);
    setStatus("Running model inference…", true);
    const resp = await fetch(`${BACKEND_URL}/process-image`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image_b64: b64, filename: getSelectedName() }),
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    state.blurredB64 = data.blurred_image_b64;
    state.boxes = data.boxes;
    setBadge(state.selected, data.boxes.length > 0 ? "error" : "processed", data.boxes.length > 0 ? `${data.boxes.length} found` : "clean");
    await showPreview(data);
    hideStatus();
  } catch (e) {
    setBadge(state.selected, "error", "error");
    setStatus(`Error: ${e.message}`, false);
  } finally {
    state.processing = false;
    $btnScan.disabled = false;
  }
}

async function showPreview(data) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      $canvas.width = img.naturalWidth;
      $canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
      if (data.boxes.length > 0) {
        ctx.strokeStyle = "#ff6600";
        ctx.lineWidth = 2;
        ctx.font = "12px sans-serif";
        ctx.fillStyle = "rgba(255,102,0,0.85)";
        data.boxes.forEach(b => {
          ctx.strokeRect(b.x1, b.y1, b.x2 - b.x1, b.y2 - b.y1);
          ctx.fillText(b.label, b.x1 + 2, b.y1 + 13);
        });
      }
      updateBoxCount(data.boxes.length);
      $preview.classList.add("visible");
      $btnReplace.disabled = data.boxes.length === 0;
      resolve();
    };
    img.src = `data:image/png;base64,${data.blurred_image_b64}`;
  });
}

async function onReplace() {
  if (!state.blurredB64) return;
  setStatus("Replacing attachment…", true);
  $btnReplace.disabled = true;
  try {
    const item = Office.context.mailbox.item;
    await new Promise((resolve, reject) => {
      item.removeAttachmentAsync(state.selected, res => {
        if (res.status === Office.AsyncResultStatus.Failed) reject(new Error(res.error.message));
        else resolve();
      });
    });
    const name = getSelectedName().replace(/(\.[^.]+)?$/, "_blurred.png");
    await new Promise((resolve, reject) => {
      item.addFileAttachmentFromBase64Async(state.blurredB64, name, { isInline: false }, res => {
        if (res.status === Office.AsyncResultStatus.Failed) reject(new Error(res.error.message));
        else resolve();
      });
    });
    setBadge(state.selected, "processed", "replaced ✓");
    hideStatus();
    onDiscard();
    loadAttachments();
  } catch (e) {
    setStatus(`Replace failed: ${e.message}`, false);
    $btnReplace.disabled = false;
  }
}

function onDiscard() {
  resetPreview();
  state.blurredB64 = null;
  state.boxes = [];
}

function readAttachmentAsBase64(attachmentId) {
  return new Promise((resolve, reject) => {
    Office.context.mailbox.item.getAttachmentContentAsync(attachmentId, {}, res => {
      if (res.status === Office.AsyncResultStatus.Failed) { reject(new Error(res.error.message)); return; }
      resolve(res.value.content);
    });
  });
}

function getSelectedName() {
  const att = state.attachments.find(a => a.id === state.selected);
  return att ? att.name : "image.png";
}

function setBadge(id, cls, text) {
  const badge = document.getElementById(`badge-${id}`);
  if (!badge) return;
  badge.className = `att-badge ${cls === "processed" ? "processed" : cls === "error" ? "error" : ""}`;
  badge.textContent = text;
}

function updateBoxCount(n) {
  $boxCount.textContent = n === 0 ? "✓ No sensitive information detected" : `⚠ ${n} sensitive region${n > 1 ? "s" : ""} blurred`;
  $boxCount.className = `box-count ${n === 0 ? "none" : "found"}`;
}

function resetPreview() {
  $preview.classList.remove("visible");
  $btnReplace.disabled = true;
  ctx.clearRect(0, 0, $canvas.width, $canvas.height);
}

function setStatus(msg, spinning) {
  $statusTxt.textContent = msg;
  $status.classList.add("visible");
  $status.querySelector(".spinner").style.display = spinning ? "block" : "none";
}

function hideStatus() { $status.classList.remove("visible"); }

function esc(str) {
  return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}