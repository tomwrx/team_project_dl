const BACKEND_URL = "https://grain-scheming-ellipse.ngrok-free.dev";
const SECRET_KEY  = "demo-secret-2024";

let blurredB64 = null;
let selectedFilename = "blurred.png";

const $fileInput   = document.getElementById("file-input");
const $selectedFile= document.getElementById("selected-file");
const $btnScan     = document.getElementById("btn-scan");
const $btnDownload = document.getElementById("btn-download");
const $btnDiscard  = document.getElementById("btn-discard");
const $status      = document.getElementById("status-bar");
const $statusTxt   = document.getElementById("status-text");
const $preview     = document.getElementById("preview-section");
const $canvas      = document.getElementById("preview-canvas");
const $boxCount    = document.getElementById("box-count");
const ctx          = $canvas.getContext("2d");

$fileInput.addEventListener("change", onFileSelected);
$btnScan.addEventListener("click", onScan);
$btnDownload.addEventListener("click", onDownload);
$btnDiscard.addEventListener("click", onDiscard);

function onFileSelected() {
  const file = $fileInput.files[0];
  if (!file) return;
  selectedFilename = file.name.replace(/(\.[^.]+)?$/, "_blurred.png");
  $selectedFile.textContent = "Selected: " + file.name;
  $selectedFile.style.display = "block";
  $btnScan.disabled = false;
  onDiscard();
}

async function onScan() {
  const file = $fileInput.files[0];
  if (!file) return;
  setStatus("Reading image...", true);
  $btnScan.disabled = true;

  try {
    const b64 = await fileToBase64(file);
    setStatus("Running model inference...", true);

    const resp = await fetch(BACKEND_URL + "/process-image", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": SECRET_KEY
      },
      body: JSON.stringify({ image_b64: b64, filename: file.name }),
    });

    if (!resp.ok) throw new Error("HTTP " + resp.status);
    const data = await resp.json();
    blurredB64 = data.blurred_image_b64;
    await showPreview(data);
    hideStatus();
  } catch (e) {
    setStatus("Error: " + e.message, false);
  } finally {
    $btnScan.disabled = false;
  }
}

async function showPreview(data) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      $canvas.width  = img.naturalWidth;
      $canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
      if (data.boxes.length > 0) {
        ctx.strokeStyle = "#ff6600";
        ctx.lineWidth   = 2;
        ctx.font        = "12px sans-serif";
        ctx.fillStyle   = "rgba(255,102,0,0.85)";
        data.boxes.forEach(b => {
          ctx.strokeRect(b.x1, b.y1, b.x2 - b.x1, b.y2 - b.y1);
          ctx.fillText(b.label, b.x1 + 2, b.y1 + 13);
        });
      }
      $boxCount.textContent = data.boxes.length === 0
        ? "✓ No sensitive information detected"
        : "⚠ " + data.boxes.length + " sensitive region" + (data.boxes.length > 1 ? "s" : "") + " blurred";
      $boxCount.className = "box-count " + (data.boxes.length === 0 ? "none" : "found");
      $preview.classList.add("visible");
      resolve();
    };
    img.src = "data:image/png;base64," + data.blurred_image_b64;
  });
}

function onDownload() {
  if (!blurredB64) return;
  const a = document.createElement("a");
  a.href = "data:image/png;base64," + blurredB64;
  a.download = selectedFilename;
  a.click();
}

function onDiscard() {
  $preview.classList.remove("visible");
  blurredB64 = null;
  ctx.clearRect(0, 0, $canvas.width, $canvas.height);
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function setStatus(msg, spinning) {
  $statusTxt.textContent = msg;
  $status.classList.add("visible");
  $status.querySelector(".spinner").style.display = spinning ? "block" : "none";
}

function hideStatus() { $status.classList.remove("visible"); }
